package com.example.hellotoast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private int mCount = 0;
    private TextView mShowCount;
    private Button mCountButton;
    private Button mZeroButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mShowCount = findViewById(R.id.show_count);
        mCountButton = findViewById(R.id.button_count);
        mZeroButton = findViewById(R.id.button_zero);
    }

    public void showToast(View view) {
        Toast toast = Toast.makeText(this,
                R.string.button_label_toast,
                Toast.LENGTH_SHORT);
        toast.show();
    }

    public void countUp(View view) {
        mCount++;

        mShowCount.setText(Integer.toString(mCount));

        if (mCount % 2 == 1) {
            mCountButton.setBackgroundColor(
                    getResources().getColor(R.color.buttonGreen));
        } else {
            mCountButton.setBackgroundColor(
                    getResources().getColor(R.color.buttonBlue));
        }

        mZeroButton.setBackgroundColor(
                getResources().getColor(R.color.buttonOrange));
    }

    public void resetCount(View view) {
        mCount = 0;

        mShowCount.setText(Integer.toString(mCount));

        mZeroButton.setBackgroundColor(
                getResources().getColor(R.color.buttonGray));

        mCountButton.setBackgroundColor(
                getResources().getColor(R.color.buttonBlue));
    }
}
